Steps : 
1. Start your Xampp Server and create a new user with username = "admin" password="admin"
2. Create new Database named : "hibernet"
3. Import the hibernet.sql file in the hibernet database
	NOTE:
		hibernet.sql file is present in database folder
4. Deploy the war file in tomcat server.